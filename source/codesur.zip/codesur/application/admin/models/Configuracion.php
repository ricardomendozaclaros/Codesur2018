<?php
class Admin_Model_Configuracion extends Z_Admin_Table {
	protected $_name = 'configuracion';
	protected $sufijo="con_";	
	
	
}
