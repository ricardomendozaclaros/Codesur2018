<?php
class Admin_Form_Link_Link extends Zend_Form {
	public function init() {
//		$this->setAttrib('id','form_admin');
//
//		$this->setDecorators(array('FormElements',array('HtmlTag', array('tag' => 'div')),'Form',));
//		$this->setElementDecorators(array('ViewHelper',array('ViewScript', array('viewScript' => 'decoradorsoloerror.phtml', 'placement' => FALSE))));
//		
//		$this->addElement('hidden','lin_id');
//
//	        $this->addElement('text','lin_orden',array(
//			'label'      => 'Orden',
//			'size'	    	=> '10',
//			'required'   => true,
//			'filters'	=>array('StringTrim','StripSlashes','Int')				
//		));
//		$this->addElement('text','lin_titulo_es',array(
//			'label'      => 'Nombre (ES)',
//			'size'		=> '50',
//			'required'   => true,
//			'filters'	=>array('StringTrim','StripSlashes'),
//			
//		));
//		
//		
//		$this->addElement('text','lin_titulo_en',array(
//			'label'      => 'Nombre (EN)',
//			'size'		=> '50',
//			'required'   => true,
//			'filters'	=>array('StringTrim','StripSlashes'),
//			
//		));
//		
//			
//		$this->addElement('text','lin_link',array(
//			'label'      => 'Link Sugerido ',
//			'size'		=> '50',
//			'required'   => true,
//			'filters'	=>array('StringTrim','StripSlashes'),							
//		));
//		
//		$this->addElement('radio','lin_estado',array(
//			'label'      => 'Mostrar',
//			'multioptions' =>array(1=>'Mostrar ',0=>'NO mostrar'),					
//			'value'=>1
//		));	
//		$this->addElement('submit','Guardar');
//		$this->addElementPrefixPath('Z_Filter', 'Z/Filter/', 'filter');	
	}
}
	
?>