<?php
class Model_Banner_Bannerposicion extends Z_Admin_Table {
	protected $_name = 'banner_posicion';
	public $sufijo="pos_";
}
