<?php
class Model_Banner_Banner extends Z_Admin_Table {
	protected $_name = 'banner';
	public $prefijo="ban_";	
	
}
