<?php
class Model_Banner_Bannerseccion extends Z_Admin_Table {
	protected $_name = 'banner_seccion';
	public $sufijo="bs_";
}
