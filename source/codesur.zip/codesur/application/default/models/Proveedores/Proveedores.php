<?php
class Model_Proveedores_Proveedores extends Z_Admin_Table {
	protected $_name = 'proveedores';
	public $prefijo="pro_";
}
