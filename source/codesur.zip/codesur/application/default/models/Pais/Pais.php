<?php
class Model_Pais_Pais extends Z_Admin_Table {
	protected $_name = 'paises';
	public $prefijo="pai_";
}
