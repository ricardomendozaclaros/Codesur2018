<?php
class Model_Noticia_Imagenes extends Z_Admin_Table {
	protected $_name = 'noticia_img';
	public $prefijo = 'img_';
	
	
}
