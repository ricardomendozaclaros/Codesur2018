<?php
class Model_Mascotas_Mascotas extends Z_Admin_Table {
	protected $_name = 'mascotas';
	public $prefijo="mas_";	
	
}
