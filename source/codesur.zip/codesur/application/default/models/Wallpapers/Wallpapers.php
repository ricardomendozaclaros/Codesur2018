<?php
class Model_Wallpapers_Wallpapers extends Z_Admin_Table {
	protected $_name = 'wallpaper';
	public $prefijo="wal_";	
	
}
