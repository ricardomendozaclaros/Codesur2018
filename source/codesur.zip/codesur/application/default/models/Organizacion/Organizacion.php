<?php
class Model_Organizacion_Organizacion extends Z_Admin_Table {
	protected $_name = 'organizacion';
	public $prefijo="org_";
}
