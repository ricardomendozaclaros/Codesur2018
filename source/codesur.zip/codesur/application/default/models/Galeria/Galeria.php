<?php
class Model_Galeria_Galeria extends Z_Admin_Table {
	protected $_name = 'galeria';
	public $sufijo = 'gal_';
	
	
}
