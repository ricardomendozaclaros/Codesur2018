<?php
class Model_Galeria_Galeriaudio extends Z_Admin_Table {
	protected $_name = 'galeria_audio';
	public $sufijo = 'aud_';
	
	
}
