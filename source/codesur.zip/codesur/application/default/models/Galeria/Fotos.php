<?php
class Model_Galeria_Fotos extends Z_Admin_Table {
	protected $_name = 'fotos';
	public $prefijo = 'fot_';
	
	
}
