<?php
class Model_Contacto_Voluntariotipo extends Z_Admin_Table {

	protected $_name = 'vountariado_tipo';
	public $prefijo = 'vol_';
	
}
