<?php
class Model_Contacto_Voluntariodatos extends Z_Admin_Table {

	protected $_name = 'voluntariado';
	public $prefijo = 'vol_';
	
}
