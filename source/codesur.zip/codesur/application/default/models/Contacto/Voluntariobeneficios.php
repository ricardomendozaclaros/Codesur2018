<?php
class Model_Contacto_Voluntariobeneficios extends Z_Admin_Table {

	protected $_name = 'voluntariado_beneficios';
	public $prefijo = 'ben_';
	
}
