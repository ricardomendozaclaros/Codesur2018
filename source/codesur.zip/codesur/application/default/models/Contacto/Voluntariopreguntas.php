<?php
class Model_Contacto_Voluntariopreguntas extends Z_Admin_Table {

	protected $_name = 'voluntariado_preguntas_frecuentes';
	public $prefijo = 'pre_';
	
}
