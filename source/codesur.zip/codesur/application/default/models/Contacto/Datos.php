<?php
class Model_Contacto_Datos extends Z_Admin_Table {

	protected $_name = 'datos_contacto';
	public $prefijo = 'con_';
	
}
