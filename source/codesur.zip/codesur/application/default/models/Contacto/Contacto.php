<?php
class Model_Contacto_Contacto extends Z_Admin_Table {

	protected $_name = 'contacto';
	public $prefijo = 'con_';
	
}
