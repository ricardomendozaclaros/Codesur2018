<?php
class Model_Contactobo_Contactobo extends Z_Admin_Table {

	protected $_name = 'contacto';
	public $prefijo = 'con_';
	
}
