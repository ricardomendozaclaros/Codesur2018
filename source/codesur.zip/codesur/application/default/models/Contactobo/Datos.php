<?php
class Model_Contactobo_Datosbo extends Z_Admin_Table {

	protected $_name = 'datos_contacto_bo';
	public $prefijo = 'con_';
	
}
