<?php
class Model_Estatico_Categoria extends Z_Admin_Table {
	protected $_name = 'estatico_categoria';
	public $prefijo = 'cat_';
	
	
}
