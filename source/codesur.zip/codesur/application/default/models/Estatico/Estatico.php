<?php
class Model_Estatico_Estatico extends Z_Admin_Table {
	protected $_name = 'estatico';
	public $prefijo="est_";
}
