//var n = jQuery.noConflict();
//n(document).ready(function(){
//    document.getElementsByClassName(".tree-checkbox").click();
////    n(".tree-checkbox").click(function(){
////        alert("dsae");
////    });
//});
